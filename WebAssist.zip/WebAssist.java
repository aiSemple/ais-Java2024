//Aaron Semple 1/29 web assignment
package ch3;
import java.util.Scanner;
public class WebAssist {

	public static void main(String[] args) {
		Scanner input = new Scanner (System.in);
		int cYear;
		int bYear;
		int age;
		int decade;
		int premiumPrice;
		System.out.print("Enter the year you were born ");
		bYear = input.nextInt();
		System.out.print("Enter the current year ");
		cYear = input.nextInt();
		age = cYear - bYear;
		decade = age /10;
		premiumPrice = decade + 15;
		System.out.println("The price for your premium subscription is " + premiumPrice );


	}

}
