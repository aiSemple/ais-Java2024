//Aaron Semple 2/25 Create a program that takes a number pattern until it hits 500
package ch6;
import java.util.Scanner;
public class CountByAnything {
	public static void main(String[] argos) {
	    Scanner input = new Scanner(System.in);
	    int countBy = 0;
	    int itemCount = 0;
	    System.out.println("Enter a number for fun  ");
	    int number = input.nextInt();
	    while(number <= 500) {
	    	System.out.print(number + " ");
	    	itemCount = itemCount + 1;
	    	number = number + countBy;
	    	if(itemCount == 10) {
	    		System.out.println();
	    		itemCount = 0;
}}}}
