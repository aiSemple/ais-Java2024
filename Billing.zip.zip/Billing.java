//Aaron Semple 2/12 Compute the price for someone's bill with overloaded parameters
public class Billing {

	public static void main(String[] arges) {
		double price = computeBill(63.);
		System.out.println("The price you are looking at is " + price);
		price = computeBill(63.,9);
		System.out.println("The price you are looking at is " + price);
		price = computeBill(63.,9,5.);
		System.out.println("The price you are looking at is " + price);
		}

		private static double computeBill(double d, int i, double e) {
			return (d*i-e)*1.08;
		}
		private static double computeBill(double d, int i) {
			return d*i*1.08;
		}
		private static double computeBill(double d) {
			return d*1.08;
		}
}