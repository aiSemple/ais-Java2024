//Aaron Semple 2/25 Create a program that counts by fives
package ch6;
import java.util.Scanner;
public class CountByFives {
	public static void main(String[] argos) {
	    Scanner input = new Scanner(System.in);
	    int countBy = 5;
	    int itemCount = 0;
	    int number = 5;
	    System.out.println("Wanna see a every 5th number to 500? ");
	    while(number <= 500) {
	    	System.out.print(number + " "); 
	    	itemCount = itemCount + 1;
	    	number = number + countBy;
	    	if(itemCount == 10) {
	    		System.out.println();
	    		itemCount = 0;
}}}}
