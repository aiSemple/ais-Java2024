//Aaron Semple 1/29 Get Sandwich
package ch3;
import java.util.Scanner;
public class TestSandwich {
public static void main(String[] args) {
    String mainIngredient;
    String bread;
    double price;
    Scanner keyboard = new Scanner(System.in);
    System.out.println("Choose a main ingredient ");
    mainIngredient = keyboard.nextLine();
    System.out.println("Choose your bread ");
    bread = keyboard.nextLine();
    System.out.println("How much would you like to pay?");
    price = keyboard.nextDouble();

    Sandwich obj = new Sandwich(mainIngredient, bread, price);

    System.out.println("What would you like for your main ingredient? " + obj.getIngredient());
    System.out.println("As for your bread? " + obj.getBread());
    System.out.println("You will be looking at " + obj.getPrice());
}
private String mainIngredient;
private String bread;
private double price;

public Sandwich(String main, String bre, double pri) {
   mainIngredient = main;
    bread = bre;
    price = pri;
}
public void setMainIngredient(String main) {
    this.mainIngredient = main;
}
public String getMainIngredient() {
    return mainIngredient;
}
public String getBread() {
    return bread;
}
public Double getPrice() {
    return price;
}
}

