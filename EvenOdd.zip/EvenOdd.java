package ch5;
//Aaron Semple 2/19 Determine whether a given number is either even or odd
import java.util.*;
public class EvenOdd {
	
	public static void main(String[] argos) {
		Scanner input = new Scanner(System.in);
		int number;
		System.out.println( "Enter an integer ");
		number = input.nextInt();
		String answer = "The number is odd";
		if(number % 2 == 0 ) {
			answer = "The number is even ";
}
System.out.println(answer);
	}
	}
