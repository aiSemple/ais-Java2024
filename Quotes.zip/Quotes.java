package ch7;
//Aaron Semple 3/4 Count the number of spaces in a given quote.
import java.util.*;
public class Quotes {
	public static void main(String[] args) {
	Scanner input = new Scanner(System.in);
	String quote;
	System.out.println("Enter your favorite quote!" );
	quote = input.nextLine();
	int spaces = 0;
	for(int i = 0; i < quote.length(); ++i) {
		if(quote.charAt(i) == ' ')
			spaces++;
		}
		System.out.println("There are " + spaces + " spaces in this quote.");
		}}
