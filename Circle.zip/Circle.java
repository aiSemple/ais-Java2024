//Aaron Semple 2/12 Circle
public class Circle {
	private double radius;
	private double diameter;
	private double area;
	public Circle() {
		this.radius = 1;
	}
	public double getRadius() {
		return radius;
	}
	public void setRadius(double radius) {
		this.radius = radius;
	}
	public double getDiameter() {
		return diameter = radius*2;
	}
	public double getArea() {
		return radius*radius*Math.PI ;
	}
	
	
}

