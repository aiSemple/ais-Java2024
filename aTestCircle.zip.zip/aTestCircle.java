//Aaron Semple 2/12 Circle calculate the area and diameter of circle with only the radius
public class aTestCircle {
	public Circle bd; 
	public static void main(String[] args) {
	Circle zero = new Circle();
	System.out.println("radius " + zero.getRadius());
	System.out.println("diameter " + zero.getDiameter());
	System.out.println("area " + zero.getArea());
	
	}
}
