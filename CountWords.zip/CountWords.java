package ch7;
//Aaron Semple 3/4 Take a quote and count the words.
import java.util.*;
public class CountWords {
	public static void main(String[] args) {
	Scanner input = new Scanner(System.in);
	String quote;
	System.out.println("Enter your favorite quote!" );
	quote = input.nextLine();
	int words = 1;
	for(int i = 0; i < quote.length(); ++i) {
		if(quote.charAt(i) == ' ')
			words++;
		}
		System.out.println("There are " + words + " words in this quote.");
		}}
