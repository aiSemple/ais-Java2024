package ch7;
//Aaron Semple 3/4 Turn a 10 digit number into a phone number.
import javax.swing.JOptionPane;
public class PhoneFormat {
	public static void main(String[] args) {
		String number; 
		String newNumber;
		number = JOptionPane.showInputDialog("Enter a 10 digit number or 999 to quit.");
		while ( !(number.equals("999")) && number.length() != 10);
{
			number = JOptionPane.showInputDialog("Enter a 10 digit number or 999 to quit.");
}
		while (!(number.equals("999"))) {
			newNumber = "(" + number.substring(0,3) + ")";
			newNumber = newNumber + number.substring(3,6) + "-";
			newNumber = newNumber + number.substring(6);
			System.out.println("The formatted number is " + newNumber);
			number = JOptionPane.showInputDialog("Enter a 10 digit number or 999 to quit.");
			while ( !(number.equals("999")) && number.length() != 10);
			{
			number = JOptionPane.showInputDialog("Enter a 10 digit number or 999 to quit.");
}}}}

