package ch5;
//Aaron Semple 2/19 Order numbers from least to greatest and vice versa
import java.util.*;
public class AscendingAndDescending{
	public static void main(String[] argos) {
		Scanner input = new Scanner(System.in);
		int number;
		int number2;
		int number3;
		System.out.println( "Enter an integer ");
		number = input.nextInt();
		System.out.println( "Enter a second integer ");
		number2 = input.nextInt();
		System.out.println( "Enter a third integer ");
		number3 = input.nextInt();
		if(number > number2 ) {
			if(number3 > number2) 
				System.out.println(number + ", " + number3 + ", " + number2 + "   " + number2 + ", " + number3 + ", " + number);
			if(number2 > number3)
				System.out.println(number + ", " + number2 + ", " + number3 + "   " + number3 + ", " + number2 + ", " + number);
		}
		if(number2 > number ) {
			if(number3 > number) 
				System.out.println(number2 + ", " + number3 + ", " + number + "   " + number + ", " + number3 + ", " + number2);
			if(number > number3)
				System.out.println(number2 + ", " + number + ", " + number3 + "   " + number3 + ", " + number + ", " + number2);
		}
		if(number3 > number2) {
			if(number > number2)
				System.out.println(number3 + ", " + number + ", " + number2 + "   " + number2 + ", " + number + ", " + number3);
			if(number2 > number3)
				System.out.println(number3 + ", " + number2 + ", " + number + "   " + number + ", " + number2 + ", " + number3);
		}
}}