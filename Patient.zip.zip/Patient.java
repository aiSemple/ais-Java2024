//Aaron Semple 2/12 Patient 
public class Patient {
	private int id;
	private int age;
	public BloodData bd;

	public Patient() {
		this.setId(0);
		this.setAge(0);
		bd = new BloodData();
	}
public Patient(int id, int age, String  type, String factor) {
	this.setId(id);
	this.setAge(age);
	bd = new BloodData(type, factor);
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
}
	
