package ch3;
import java.util.Scanner;
public class InchConversion {
	
	public static void main(String[] args) {
		Scanner input = new Scanner (System.in);
		int inches;
		double feet;
		double yards;
		System.out.print("Enter the number of inches ");
		inches = input.nextInt();
		feet = inches/12;
		yards = feet/3;
		System.out.println(inches + " is equal to " + feet + " feet and is equal to " + yards + " in yards.");




	}

}
