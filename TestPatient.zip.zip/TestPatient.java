//Aaron Semple 2/12 TestPatient Use the blood data and patient data you have gathered to print their information
public class TestPatient {

	public static void main(String[] args) {
	Patient zero = new Patient();
	System.out.println("Patient id " + zero.getId());
	System.out.println("Patient age " + zero.getAge());
	System.out.println("Blood Type " + zero.bd.getType());
	System.out.println("Blood factor " + zero.bd.getFactor());

	Patient one = new Patient(777, 45, "AB", "-");
	System.out.println("Patient id " + one.getId());
	System.out.println("Patient age " + one.getAge());
	System.out.println("Blood Type " + one.bd.getType());
	System.out.println("Blood factor " + one.bd.getFactor());
	}

}
