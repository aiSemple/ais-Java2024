package ch5;
//Aaron Semple 2/19 Create a set of code to determine who is a worthy applicant
public class JobApplicant {
	private String name;
private String phone;
private boolean word;
private boolean excel;
private boolean access;
private boolean graphics;
public JobApplicant(String name, String phone, boolean word, boolean excel, boolean access, boolean graphics) {
this.name = name;
this.phone = phone;
this.word = word;
this.excel = excel;
this.access = access;
this.graphics = graphics;
}
	public String getName() {
		return name;
}
	public String getPhone() {
		return phone;
}
public boolean isWord() {
		return word;
}
	public boolean isExcel() {
		return excel;
}
	public boolean isAccess() {
		return access;
}
	public boolean isGraphics() {
		return graphics;
}

}
