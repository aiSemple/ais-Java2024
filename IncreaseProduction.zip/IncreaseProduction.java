//Aaron Semple 2/25 Calculate an increase of production
package ch6;
public class IncreaseProduction {
	public static void main(String[] argos) {
	   int parts = 4000;
	   boolean getsRaise = false;
	   System.out.println("month" + "	" + parts);
	   for(int month = 1; month<= 24; ++month) {
		   System.out.println(month + "  " + parts);
		   if(parts >= 7000 && getsRaise == false) {
			   System.out.println("Worker gets a raise");
			   getsRaise = true;
			   }
		   parts = (int) (parts * 1.06);
}}}
