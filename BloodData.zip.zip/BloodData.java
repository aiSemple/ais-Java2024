//Aaron Semple 2/12 BloodData
public class BloodData {
	private String type;
	private String factor;
	public BloodData() {
		this.type = "0";
		this.setFactor("+");
		}
	public BloodData(String type, String factor) {
		this.setType(type);
		this.setFactor(factor);
}
	public String getType() {
		return type;
		}
	public void setType(String Type) {
		this.type = type;
		}
	public String getFactor() {
		return factor;
		}
	public void setFactor(String factor) {
		this.factor = factor;
		}
	}
		
