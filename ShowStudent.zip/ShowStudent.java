//Aaron Semple 1/29 Student gpa
package ch3;
public class ShowStudent {
	
	public static void main (String args[])
	{
	Student child = new Student();
	child.setIdNumber(9999);
	child.setPoints(12);
	child.setHours(3);
	child.showIdNumber();
	child.showPoints();
	child.showHours();
	System.out.println("The child’s GPA is " +
	child.getGradePoint());
	}
	
	}


