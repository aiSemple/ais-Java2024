package ch5;
//Aaron Semple 2/19 Test the job applicant code 
public class TestJobApplicant {
	
	public static void main(String[] argos) {
		JobApplicant one = new JobApplicant("one", "123", true, true, true, true);
		JobApplicant two = new JobApplicant("two", "1234", true, true, false, false);
		if(isQualified(one)) {
			System.out.println(one.getName() + " is qualified for an interview");
		}
		else {
			System.out.println(one.getName() + " is NOT qualified for an interview");
		}
		if(isQualified(two)) {
			System.out.println(two.getName() + " is qualified for an interview");
		}
		else {
			System.out.println(two.getName() + " is NOT qualified for an interview");
		}
}
	private static boolean isQualified(JobApplicant any) {
		boolean returnValue =false;
		int count = 0;
		if(any.isWord())
			count++;
		if(any.isExcel())
			count++;
		if(any.isAccess())
			count++;
		if(any.isGraphics())
			count++;
		if(count>=3)
			returnValue = true;
		return returnValue;
			}
		}
