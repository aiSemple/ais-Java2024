package ch3;
import java.util.Scanner;
public class PaintCalculator {

	public static void main(String[] args) {
		Scanner input = new Scanner (System.in);
		double length;
		double width;
		double height;
		double gallons;
		double totalCost;
		double area;
		System.out.print("Enter the length of the wall ");
		length = input.nextInt();
		System.out.print("Enter the width of the wall ");
		width = input.nextInt();
		System.out.print("Enter the height of the wall ");
		height = input.nextInt();
		area = length * width;
		gallons = area/350;
		totalCost = gallons * 32;
		System.out.println( "The number of gallons needed is " + gallons + ". $32 per gallon which makes your total " + totalCost + "$.");


	}

}
