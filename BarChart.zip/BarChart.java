//Aaron Semple 2/26 Record the scores for basketball players
package ch6;
import java.util.Scanner;
public class BarChart {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String p = "";
		String b = "*";
		System.out.println("Enter points earned by Art >> ");
		int art = input.nextInt();
		System.out.println("Enter points earned by Bob >> ");
		int bob = input.nextInt();
		System.out.println("Enter points earned by Cal >> ");
		int cal = input.nextInt();
		System.out.println("Enter points earned by Dan >> ");
		int dan = input.nextInt();
		System.out.println("Enter points earned by Eli >> ");
		int eli = input.nextInt();
		System.out.println("Points for game ");
		for(int points = 0; points < art; ++points) {
			while(points <= art || points <= bob || points <= cal || points <= dan || points <= eli) {
			p = p + b;
			points = points + 1;
			if(points == art) {
			System.out.println("Art " + p);
			}
			if(points == bob) {
			System.out.println("Bob " + p);
				}
			if(points == cal) {
			System.out.println("Cal " + p);
					}
			if(points == dan) {
			System.out.println("Dan " + p);
					}
			if(points == eli) {
			System.out.println("Eli " + p);
					}
			
	
	}

			}}}
