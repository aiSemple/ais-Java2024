
public class Assignment1 {

	public static void main(String[] args) {
		double sqrt = 37;
		double sines = 300;
		double fcr = 22.8;
		int Int = 71;
		String d = "d";
		System.out.println("The square root of 37 is " + Math.sqrt(sqrt));
		System.out.println("The sine and cosine of 300 is " + Math.sin(sines) + " and " + Math.cos(sines));
		System.out.println("The floor, ceiling, and round of 22.8 is " + Math.floor(fcr) + ", " + Math.ceil(fcr) + " and " + Math.round(fcr));
		System.out.println("The uppercase and lowercase of the letter D is " + d.toUpperCase()+ " and " + d.toLowerCase());
		System.out.println("The integer of 71 is " + Math.rint(Int));
		System.out.println("A random number between zero and twenty is " + Math.random()*20);
	}

}
