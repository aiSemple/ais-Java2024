//Aaron Semple 2/26 Program Diagonal O's using a loop
package ch6;
public class DiagonalOs {
	public static void main(String[] args) {
		String o = "O";
		String space = " ";
		String t = "";
		for(int count = 0; count<= 10; ++count) {
			if (count <= 10) {
				System.out.println(t + o);
				t = t + space ;
			}

}}}
